package com.example.doorsteptailors;

public class UserDetails {
    private String T_Id,name,username,address,ConNo,email,pw,asSignIn,shopName,WorkingExperience,Availability,Rating;

    public void setT_Id(String T_Id) {
        this.T_Id = T_Id;
    }
    public String getT_Id() {
        return T_Id;
    }

    public void setname(String name) {
        this.name = name;
    }
    public String getname() {
        return name;
    }

    public void setusername(String username) {
        this.username = username;
    }

    public String getusername() {
        return username;
    }

    public void setaddress(String address) {
        this.address = address;
    }

    public String getaddress() {
        return address;
    }



    public String getConNo() {
        return ConNo;
    }

    public void setConNo(String conNo) {
        ConNo = conNo;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getPw() {
        return pw;
    }

    public void setPw(String pw) {
        this.pw = pw;
    }

    public String getShopName() {
        return shopName;
    }

    public void setShopName(String shopName) {
        this.shopName = shopName;
    }

    public String getWorkingExperience() {
        return WorkingExperience;
    }

    public void setWorkingExperience(String WorkingExperience) {
        this.WorkingExperience = WorkingExperience;
    }

    public String getAvailability() {
        return Availability;
    }

    public void setAvailability(String Availability) {
        this.Availability = Availability;
    }

    public String getRating() {
        return Rating;
    }

    public void setRating(String Rating) {
        this.Rating = Rating;
    }


}
