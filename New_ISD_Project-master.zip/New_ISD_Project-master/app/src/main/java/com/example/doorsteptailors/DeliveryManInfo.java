package com.example.doorsteptailors;

public class DeliveryManInfo {
    String D_Name,D_PhnNo,D_Gender;

    public void setD_Name(String D_Name) {
        this.D_Name = D_Name;
    }
    public String getD_Name() {
        return D_Name;
    }

    public void setD_PhnNo(String D_PhnNo) {
        this.D_PhnNo = D_PhnNo;
    }
    public String getD_PhnNo() {
        return D_PhnNo;
    }

    public void setD_Gender(String D_Gender) {
        this.D_Gender = D_Gender;
    }
    public String getD_Gender() {
        return D_Gender;
    }
}
