package com.example.doorsteptailors;

public class TailorListItems {
    String TailorName,Availability,Rating;

    public String getTailorName() {
        return TailorName;
    }
    public void setTailorName(String TailorName) {
        this.TailorName = TailorName;
    }

    public void setAvailability(String Availability) {
        this.Availability = Availability;
    }

    public String getAvailability() {
        return Availability;
    }



    public String getRating() {
        return Rating;
    }

    public void setRating(String Rating) {
        this.Rating = Rating;
    }
}
